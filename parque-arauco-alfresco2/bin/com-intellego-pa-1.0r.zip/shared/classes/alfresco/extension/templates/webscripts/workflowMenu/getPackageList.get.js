var taskId= args.taskId;

if (taskId!=null && taskId!=undefined) 
{ 
	model.list = WorkflowUtils.getNodeList("activiti$"+taskId);
}


