model.ticket = GetTicket.getTicket(person.properties.userName);
