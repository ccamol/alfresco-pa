<import resource="classpath:alfresco/extension/objectModel.js">

model.resultSet = AreaService.getAll();

var response = AreaService.getAll();;

//logger.log("Status: " + response.status);
//logger.log("Message: " + response.message);
if(response.result!=null){
//	logger.log("Size: " + response.result.size());
}






