model.ticket=TicketAlfresco.getTicket();
