<import resource="classpath:alfresco/extension/objectModelParqueArauco.js">

model.resultSet = DataListService.getDataList("paList");
