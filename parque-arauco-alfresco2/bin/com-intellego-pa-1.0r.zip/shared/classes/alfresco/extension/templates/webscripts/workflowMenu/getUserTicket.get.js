model.ticket=session.getTicket();
