var resultSet = OrganizationalAreasSrv.getAll();
if(resultSet.status > -1){
	model.resultSet = resultSet;
}else{
	model.resultSet = null;
}

