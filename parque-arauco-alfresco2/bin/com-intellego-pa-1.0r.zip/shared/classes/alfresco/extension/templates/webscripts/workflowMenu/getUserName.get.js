model.user=person.properties.userName;
